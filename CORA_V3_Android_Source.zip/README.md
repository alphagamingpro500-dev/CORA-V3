# CORA V3 — Android starter project

Interface sombre, bibliothèque locale d'images, import multi-sélection, choix écran accueil/verrouillage, intervalle, sélection aléatoire, prévention des répétitions, application immédiate et planification WorkManager.

## Construire l'APK
1. Installer Android Studio récent et un JDK 17.
2. Ouvrir le dossier `CORA_V3_Android`.
3. Laisser Gradle synchroniser les dépendances.
4. Dans Build > Build Bundle(s) / APK(s) > Build APK(s).
5. APK debug : `app/build/outputs/apk/debug/app-debug.apk`.

## Limites de cette première base
Cette version est un socle fonctionnel, pas encore une implémentation complète de chaque détail de la vidéo. L'intervalle WorkManager est soumis aux optimisations Android et a un minimum de 15 minutes. Les cycles activité/repos, plages horaires, éditeur image (luminosité/contraste/saturation/rotation/recadrage), favoris, tri, recherche et reprise au redémarrage nécessitent les modules suivants. Testez le ciblage accueil/verrouillage sur votre modèle Android : certains fabricants imposent des restrictions.
