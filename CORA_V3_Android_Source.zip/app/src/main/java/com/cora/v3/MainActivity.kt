package com.cora.v3

import android.app.Activity
import android.app.WallpaperManager
import android.content.Intent
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.view.setPadding
import androidx.work.*
import java.util.concurrent.TimeUnit
import kotlin.random.Random

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("cora", MODE_PRIVATE) }
    private val images = mutableListOf<String>()
    private lateinit var listText: TextView
    private lateinit var status: TextView
    private val picker = registerForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        uris?.forEach { uri ->
            try { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
            if (!images.contains(uri.toString())) images.add(uri.toString())
        }
        saveImages()
        renderList()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = 0xFF0B0D12.toInt()
        window.navigationBarColor = 0xFF0B0D12.toInt()
        loadImages()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24)
            setBackgroundColor(0xFF0B0D12.toInt())
        }
        fun label(text: String, size: Float, color: Int = 0xFFF2F4F8.toInt()) = TextView(this).apply {
            this.text = text; textSize = size; setTextColor(color); setPadding(0, 10, 0, 10)
        }
        root.addView(label("CORA V3", 30f))
        root.addView(label("WALLPAPER AUTOMATION", 11f, 0xFF8D96A8.toInt()))
        status = label("Prêt à personnaliser ton écran.", 14f, 0xFFB6C0D1.toInt())
        root.addView(status)
        val add = button("＋  Importer des images") { picker.launch(arrayOf("image/jpeg", "image/png", "image/webp", "image/*")) }
        root.addView(add)
        root.addView(label("Écrans à modifier", 18f))
        val target = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item,
                listOf("Accueil et verrouillage", "Accueil uniquement", "Verrouillage uniquement"))
            setSelection(prefs.getInt("target", 0))
            setOnItemSelectedListener(object : android.widget.AdapterView.OnItemSelectedListener {
                override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}
                override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: View?, position: Int, id: Long) {
                    prefs.edit().putInt("target", position).apply()
                }
            })
        }
        root.addView(target)
        root.addView(label("Intervalle automatique", 18f))
        val interval = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item,
                listOf("Toutes les 15 minutes", "Toutes les 30 minutes", "Toutes les heures", "Toutes les 3 heures", "Toutes les 6 heures", "Toutes les 12 heures", "Chaque jour"))
            val values = listOf(15L,30L,60L,180L,360L,720L,1440L)
            setSelection(values.indexOf(prefs.getLong("interval", 60L)).coerceAtLeast(0))
            onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
                override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}
                override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: View?, position: Int, id: Long) {
                    prefs.edit().putLong("interval", values[position]).apply()
                }
            }
        }
        root.addView(interval)
        val random = CheckBox(this).apply {
            text = "Choisir une image aléatoire"; setTextColor(0xFFE5E9F2.toInt())
            isChecked = prefs.getBoolean("random", true)
            buttonTintList = android.content.res.ColorStateList.valueOf(0xFF8B7CFF.toInt())
            setOnCheckedChangeListener { _, checked -> prefs.edit().putBoolean("random", checked).apply() }
        }
        root.addView(random)
        val avoid = CheckBox(this).apply {
            text = "Éviter les répétitions immédiates"; setTextColor(0xFFE5E9F2.toInt())
            isChecked = prefs.getBoolean("avoid", true)
            setOnCheckedChangeListener { _, checked -> prefs.edit().putBoolean("avoid", checked).apply() }
        }
        root.addView(avoid)
        root.addView(button("▶  Activer le changement automatique") { schedule() })
        root.addView(button("⏸  Désactiver l’automatisation") {
            WorkManager.getInstance(this).cancelUniqueWork("cora_wallpaper")
            status.text = "Automatisation désactivée."
        })
        root.addView(button("◉  Appliquer maintenant") { applyWallpaper() })
        root.addView(label("Bibliothèque d’images", 18f))
        listText = label("", 13f, 0xFFB6C0D1.toInt())
        root.addView(listText)
        root.addView(button("Effacer la bibliothèque") { images.clear(); saveImages(); renderList() })
        val scroll = ScrollView(this).apply { addView(root) }
        setContentView(scroll)
        renderList()
    }

    private fun button(text: String, action: () -> Unit) = Button(this).apply {
        this.text = text
        setTextColor(0xFFFFFFFF.toInt())
        setBackgroundTintList(android.content.res.ColorStateList.valueOf(0xFF6558D3.toInt()))
        setOnClickListener { action() }
    }
    private fun loadImages() {
        images.clear()
        images.addAll(prefs.getString("images", "")!!.split("\n").filter { it.isNotBlank() })
    }
    private fun saveImages() { prefs.edit().putString("images", images.joinToString("\n")).apply() }
    private fun renderList() {
        if (!::listText.isInitialized) return
        listText.text = if (images.isEmpty()) "Aucune image importée pour le moment." else
            images.mapIndexed { i, uri -> "${i + 1}. ${Uri.parse(uri).lastPathSegment ?: "Image"}" }.joinToString("\n")
    }
    private fun schedule() {
        if (images.isEmpty()) { status.text = "Importe d’abord au moins une image."; return }
        val minutes = prefs.getLong("interval", 60L)
        val request = PeriodicWorkRequestBuilder<WallpaperWorker>(minutes.coerceAtLeast(15), TimeUnit.MINUTES).build()
        WorkManager.getInstance(this).enqueueUniquePeriodicWork("cora_wallpaper", ExistingPeriodicWorkPolicy.UPDATE, request)
        status.text = "Automatisation activée. Android peut décaler les tâches en arrière-plan."
    }
    private fun applyWallpaper() {
        if (images.isEmpty()) { status.text = "Importe d’abord au moins une image."; return }
        try {
            val uri = Uri.parse(chooseImage())
            val bitmap = contentResolver.openInputStream(uri).use { BitmapFactory.decodeStream(it) }
            val wm = WallpaperManager.getInstance(this)
            when (prefs.getInt("target", 0)) {
                1 -> wm.setBitmap(bitmap, null, true, WallpaperManager.FLAG_SYSTEM)
                2 -> wm.setBitmap(bitmap, null, true, WallpaperManager.FLAG_LOCK)
                else -> wm.setBitmap(bitmap)
            }
            status.text = "Fond d’écran appliqué."
        } catch (e: Exception) { status.text = "Impossible d’appliquer cette image : ${e.localizedMessage ?: "format non pris en charge"}" }
    }
    private fun chooseImage(): String {
        val previous = prefs.getString("last", "")
        val candidates = if (prefs.getBoolean("avoid", true) && images.size > 1) images.filter { it != previous } else images
        val selected = if (prefs.getBoolean("random", true)) candidates.random() else images.first()
        prefs.edit().putString("last", selected).apply()
        return selected
    }
}

class WallpaperWorker(appContext: android.content.Context, params: WorkerParameters) : Worker(appContext, params) {
    override fun doWork(): Result {
        val prefs = applicationContext.getSharedPreferences("cora", Activity.MODE_PRIVATE)
        val images = prefs.getString("images", "")!!.split("\n").filter { it.isNotBlank() }
        if (images.isEmpty()) return Result.success()
        return try {
            val previous = prefs.getString("last", "")
            val candidates = if (prefs.getBoolean("avoid", true) && images.size > 1) images.filter { it != previous } else images
            val uri = Uri.parse(if (prefs.getBoolean("random", true)) candidates.random() else images.first())
            val bitmap = applicationContext.contentResolver.openInputStream(uri).use { BitmapFactory.decodeStream(it) }
            val target = prefs.getInt("target", 0)
            val wm = WallpaperManager.getInstance(applicationContext)
            when (target) {
                1 -> wm.setBitmap(bitmap, null, true, WallpaperManager.FLAG_SYSTEM)
                2 -> wm.setBitmap(bitmap, null, true, WallpaperManager.FLAG_LOCK)
                else -> wm.setBitmap(bitmap)
            }
            prefs.edit().putString("last", uri.toString()).apply()
            Result.success()
        } catch (_: Exception) { Result.retry() }
    }
}
